/**
 * 
 */
/**
 * 
 */
module Word_Count_App {
	requires java.desktop;
}
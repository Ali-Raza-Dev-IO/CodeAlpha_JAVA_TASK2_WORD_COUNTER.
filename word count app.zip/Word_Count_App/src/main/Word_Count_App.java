package main;
import javax.swing.*;
import java.awt.*;

public class Word_Count_App {
    public static void main(String[] args) {
        // Create JFrame
        JFrame frame = new JFrame("Word Counter App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 500);
        frame.setLayout(new BorderLayout());

     // Load and Set Icon
        try {
            ImageIcon icon = new ImageIcon("icon.png"); // Replace with your file path
            frame.setIconImage(icon.getImage());
        } catch (Exception e) {
            System.out.println("Icon file not found: " + e.getMessage());
        }
        
        // Create JTextArea
        JTextArea textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Create JPanel for buttons and label
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        JButton countButton = new JButton("Count Words");
        JButton clearButton = new JButton("Clear Text");
        JLabel wordCountLabel = new JLabel("Words: 0");

        panel.add(countButton);
        panel.add(clearButton);
        panel.add(wordCountLabel);

        frame.add(panel, BorderLayout.SOUTH);

        // Add ActionListener to Count Button
        countButton.addActionListener(e -> {
            String text = textArea.getText().trim();
            if (!text.isEmpty()) {
                int wordCount = text.split("\\s+").length;
                wordCountLabel.setText("Words: " + wordCount);
            } else {
                wordCountLabel.setText("Words: 0");
            }
        });

        // Add ActionListener to Clear Button
        clearButton.addActionListener(e -> {
            textArea.setText(""); // Clears the JTextArea
            wordCountLabel.setText("Words: 0"); // Resets the word count
        });

        // Set frame visibility
        frame.setVisible(true);
    }
}
